﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;
using HtmlAgilityPack;

namespace ConsoleApplication1
{
    class Program
    {



        static void Main(string[] args)
        {
            string url = "http://www.kijiji.ca/b-cars-trucks/city-of-toronto/2014__2015/c174l1700273a68?price=__15000";


            List<UsedCar> list = new List<UsedCar>();

            Console.WriteLine("Extracting...\nPlease Wait\n");
            list = getInfo(url, 1, list);
            writeToTxt(list);
            Console.WriteLine("Done, total get " + list.Count() + " record");

            Console.Read();


        }

        static void writeToTxt(List<UsedCar> list)
        {
            try
            {

                //Pass the filepath and filename to the StreamWriter Constructor
                string filePath = @"C:\Users\Franky\Desktop\DAC group\" + DateTime.Today.Year+"_"+DateTime.Today.Month+"_"+DateTime.Today.Day + "_data.txt";

                if (!File.Exists(filePath))
                {
                    File.Create(filePath);
                }

                StreamWriter sw = new StreamWriter(filePath);


                //Write a summary
                sw.WriteLine(DateTime.Today +" has "+list.Count+" records ");

                foreach (var item in list)
                {
                    //Write a line of text
                    string txt = "Name: " + item.Title + "\tDescription: " + item.Description + "\tPrice: " + item.Price + "\tPage: " + item.PageNumber;
                    sw.WriteLine(txt);
                }


                //Close the file
                sw.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
           
        }

        static List<UsedCar> getInfo(string url, int pageNumber, List<UsedCar> list)
        {
            try
            {
                HtmlWeb web = new HtmlWeb();
                HtmlDocument doc = web.Load(url);


                var findclasses = doc.DocumentNode.Descendants("table").Where(d =>
                    d.Attributes.Contains("class") && d.Attributes["class"].Value.Contains("regular-ad js-hover")
                );

                foreach (var child in findclasses)
                {
                    UsedCar item = new UsedCar();

                    item.PageNumber = pageNumber;

                    var car = child.Descendants("td").Where(d => d.Attributes.Contains("class") && d.Attributes["class"].Value.Contains("description"))
                        .FirstOrDefault();

                    var title = car.Descendants("a").Where(d => d.Attributes.Contains("class") && d.Attributes["class"].Value.Contains("title")).FirstOrDefault();
                    item.Title = title.InnerText.Trim();

                    var desc = car.Descendants("p").Where(d => d.Attributes.Contains("class") && d.Attributes["class"].Value.Contains("details")).FirstOrDefault();
                    item.Description = desc.InnerText.Trim();

                    var price = child.Descendants("td").Where(d => d.Attributes.Contains("class") && d.Attributes["class"].Value.Contains("price")).FirstOrDefault();
                    item.Price = price.InnerText.Trim();

                    list.Add(item);
                }

                //find next page
                var next = doc.DocumentNode.SelectNodes("//a[@title='Next']");



                if (next == null)
                {
                    return list;
                }
                else
                {
                    string nextUrl = "http://www.kijiji.ca" + next.FirstOrDefault().GetAttributeValue("href", null);
                    return getInfo(nextUrl, pageNumber + 1, list);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message, "Error");
                return null;
            }
        }

        class UsedCar
        {
            public int PageNumber { get; set; }
            public string Title { get; set; }
            public string Description { get; set; }
            public string Price { get; set; }
        }
    }
}
